import json
import math
import random
import seaborn as sns
import pyproj
from matplotlib import pyplot as plt
from TR38901_scalar import calculate_path_loss
import json
import numpy as np





def ax_trans(lon, lat):
    proj = pyproj.Proj("+proj=utm +zone=50 +ellps=WGS84 +datum=WGS84 tunits=m +no_defs")
    x, y = proj(lon, lat)  
    return x, y


def ll_trans(x, y):
    proj = pyproj.Proj("+proj=utm +zone=50 +ellps=WGS84 +datum=WGS84 tunits=m +no_defs")
    lon, lat = proj(x, y, inverse=True)
    return [lon, lat]


with open('out_bs_info.json', 'r') as file:  
    js = file.read()
    bs = json.loads(js)

with open('grid_info.json', 'r') as file:  
    js = file.read()
    sg = json.loads(js)

dist = np.zeros(177 * 156)

for i in sg:
    x = sg[i]['xy'][0]
    y = sg[i]['xy'][1]
    for j in bs:
        x1 = bs[j]['xy_position'][0]
        y1 = bs[j]['xy_position'][1]
        if ((x-5) <= x1 < (x+5)) & ((y-5) <= y1 < (y+5)):
            dist[int(i)] += 1

print(sum(dist))

json.dump({'is_grid_bs': dist.tolist()}, fp=open('./out_is_grid_bs' + '.json', 'w'))

dist = dist.reshape((177, 156))

plt.style.use('ggplot')

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']

plt.rcParams['axes.unicode_minus'] = False
fig = plt.figure(figsize=(40, 40))
ax = fig.add_subplot(1, 1, 1)
p1 = sns.heatmap(data=dist[::-1],  
                 cmap='PuBuGn',  
                 linewidths=.01,  
                 annot=False,  
                 ax=ax,
                 fmt='.1e'  
                 )
s1 = p1.get_figure()
s1.savefig('室外基站分布.jpg', dpi=200, bbox_inches='tight')

plt.show()
