import json

if __name__ == '__main__':
    with open('input/rl_data.json') as f:
        data = json.load(f)

    debug = True