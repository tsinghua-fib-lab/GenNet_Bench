import numpy as np
import random
import json


grid_height = 177
grid_width = 156



num_users = 4000  
num_time_steps = 5000  


user_positions = np.zeros((num_users, 2), dtype=int)
user_trajectories = np.zeros((num_users, num_time_steps, 2), dtype=int)


grid_counts = np.zeros((num_time_steps, grid_height, grid_width), dtype=int)


directions = [(0, 1), (0, -1), (-1, 0), (1, 0)]

for user in range(num_users):
    
    user_positions[user] = [random.randint(0, grid_width-1), random.randint(0, grid_height-1)]
    user_trajectories[user, 0] = user_positions[user]
    grid_counts[0, user_positions[user][1], user_positions[user][0]] += 1

for t in range(1, num_time_steps):
    for user in range(num_users):
        while True:
            direction = random.choice(directions)
            new_position = user_positions[user] + direction
            
            if 0 <= new_position[0] < grid_width and 0 <= new_position[1] < grid_height:
                user_positions[user] = new_position
                user_trajectories[user, t] = new_position
                grid_counts[t, new_position[1], new_position[0]] += 1
                break

for i in range(num_time_steps):
    total = np.sum(grid_counts[i])
    print("Time step", i)
    print(total)
    assert total == 4000, f"Error at time step {i}: The sum is not equal to 2000."


grid_counts_list = grid_counts.tolist()


with open('user_track_{}user_{}step'.format(num_users, num_time_steps), 'w') as json_file:
    json.dump(grid_counts_list, json_file)

print("JSON file has been saved successfully!")
