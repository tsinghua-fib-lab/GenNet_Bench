import math
print(math.pow(10, (-174 / 10 + math.log10(1.8e5))))
print(math.pow(10, (-174 / 10)) * 1.8e5)